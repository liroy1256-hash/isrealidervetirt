class_name World
extends Node3D
## עולם סכמטי בהשראת תל אביב: רשת רחובות, גרף ניווט ופיזור POI.
## טעינה הדרגתית: אריחים (2x2 בלוקים) נטענים לפי מיקום וכיוון נסיעה, ומשוחררים כשהשחקן מתרחק.

const N := 24
const S := 64.0
const R := 14.0
const SET := 4.0
const CHUNK := 2
const SIZE := 1536.0

const V_NAMES := {0: "טיילת הרברט סמואל", 3: "רחוב בן יהודה", 7: "רחוב דיזנגוף", 12: "רחוב אבן גבירול", 22: "נתיבי איילון"}
const H_NAMES := {4: "רחוב ארלוזורוב", 8: "רחוב פרישמן", 12: "שדרות רוטשילד", 16: "רחוב אלנבי", 20: "רחוב ז'בוטינסקי"}
const ONEWAY_V := {5: 1}
const ONEWAY_H := {10: 1}
const LAND := {
    Vector2i(20, 5): ["מגדלי עזריאלי", "azrieli"],
    Vector2i(20, 6): ["קניון עזריאלי", "mall"],
    Vector2i(13, 3): ["קניון TLV", "mall"],
    Vector2i(3, 16): ["שוק הכרמל", "market"],
    Vector2i(0, 11): ["חוף תל אביב", "beach"],
    Vector2i(9, 13): ["שדרות רוטשילד", "plaza"],
    Vector2i(21, 12): ["נתיבי איילון", "ayalon"],
}
const R_NAMES := ["פלאפל הפינה", "שווארמה הכיכר", "פיצה הים", "המבורגר העיר", "קפה הבוקר", "מאפיית הלחם", "סושי הנמל", "חומוס השכונה", "פיצה שמש", "בורקס הדר", "קפה לב העיר", "סלט וקפה"]
const B_NAMES := ["בנק העיר", "בנק הים", "בנק המרכז"]
const PALETTE := [Color("efe9dd"), Color("e6e0d2"), Color("f4f1ea"), Color("dcd6c8"), Color("e9e4d6"), Color("d7dde0")]
const SIGN_COLS := [Color("c0392b"), Color("e67e22"), Color("27ae60"), Color("8e44ad"), Color("2980b9"), Color("d35400")]

var load_r := 2
var chunks := {}
var astar := AStar2D.new()
var _queue: Array = []
var _poi_cache := {}
var _mats := {}
var street_lights: Array[OmniLight3D] = []


func _ready() -> void:
    for j in range(N + 1):
        for i in range(N + 1):
            astar.add_point(_nid(i, j), Vector2(i * S, j * S))
    for j in range(N + 1):
        for i in range(N + 1):
            if i < N:
                _link(_nid(i, j), _nid(i + 1, j), int(ONEWAY_H.get(j, 0)))
            if j < N:
                _link(_nid(i, j), _nid(i, j + 1), int(ONEWAY_V.get(i, 0)))
    _build_ground()


func _nid(i: int, j: int) -> int:
    return j * (N + 1) + i


func _link(a: int, b: int, dir: int) -> void:
    if dir == 0:
        astar.connect_points(a, b, true)
    elif dir > 0:
        astar.connect_points(a, b, false)
    else:
        astar.connect_points(b, a, false)


func _h(i: int, j: int) -> int:
    return absi(((i + 7) * 73856093) ^ ((j + 13) * 19349663))


# ---------- נתונים ----------
func poi(i_in, j_in) -> Dictionary:
    var i := int(i_in)
    var j := int(j_in)
    var key := Vector2i(i, j)
    if _poi_cache.has(key):
        return _poi_cache[key]
    var h := _h(i, j)
    var kind := "home"
    var nm := ""
    var sub := ""
    if LAND.has(key):
        kind = "landmark"
        nm = LAND[key][0]
        sub = LAND[key][1]
    else:
        var m := h % 100
        if m < 11:
            kind = "restaurant"
            nm = R_NAMES[floori(h / 100.0) % R_NAMES.size()]
        elif m < 14:
            kind = "bank"
            nm = B_NAMES[floori(h / 100.0) % B_NAMES.size()]
    var addr := "%s %d" % [street_name_h(j + 1), 1 + floori(h / 7.0) % 60]
    var p := {
        "kind": kind, "name": nm if nm != "" else addr, "sub": sub, "i": i, "j": j, "h": h,
        "door": Vector3(i * S + S * 0.5, 0.0, (j + 1) * S - R * 0.5 - SET * 0.5),
        "node": Vector2i(i, j + 1), "addr": addr,
    }
    _poi_cache[key] = p
    return p


func random_poi(kind: String, near: Vector3, radius: float) -> Dictionary:
    for _t in range(300):
        var p := poi(randi() % N, randi() % N)
        if p.kind == kind and p.door.distance_to(near) <= radius and p.door.distance_to(near) > 40.0:
            return p
    for i in range(N):
        for j in range(N):
            var p := poi(i, j)
            if p.kind == kind:
                return p
    return poi(0, 0)


func nearest_poi(kind: String, pos: Vector3) -> Dictionary:
    var best := {}
    var bd := 1e12
    for i in range(N):
        for j in range(N):
            var p := poi(i, j)
            if p.kind == kind:
                var d: float = p.door.distance_to(pos)
                if d < bd:
                    bd = d
                    best = p
    return best


func destinations(pos: Vector3) -> Array:
    var out: Array = []
    for k in LAND:
        out.append(poi(k.x, k.y))
    var r := nearest_poi("restaurant", pos)
    if not r.is_empty():
        out.append(r)
    var b := nearest_poi("bank", pos)
    if not b.is_empty():
        out.append(b)
    return out


func street_name_h(row: int) -> String:
    return H_NAMES.get(row, "רחוב %d" % row)


func street_name_v(col: int) -> String:
    return V_NAMES.get(col, "רחוב %d" % (col + 30))


func street_name(a: Vector3, b: Vector3) -> String:
    if absf(b.x - a.x) > absf(b.z - a.z):
        return street_name_h(roundi(a.z / S))
    return street_name_v(roundi(a.x / S))


func route(from: Vector3, p: Dictionary) -> PackedVector3Array:
    var a := _nid(clampi(roundi(from.x / S), 0, N), clampi(roundi(from.z / S), 0, N))
    var b := _nid(p.node.x, p.node.y)
    var out := PackedVector3Array()
    for id in astar.get_id_path(a, b):
        out.append(Vector3((id % (N + 1)) * S, 0.0, floori(float(id) / (N + 1)) * S))
    out.append(p.door)
    return out


# ---------- טעינה הדרגתית ----------
func _cc(pos: Vector3) -> Vector2i:
    return Vector2i(floori(pos.x / (CHUNK * S)), floori(pos.z / (CHUNK * S)))


func _valid(c: Vector2i) -> bool:
    return c.x >= 0 and c.y >= 0 and c.x < N / CHUNK and c.y < N / CHUNK


func _wanted(pos: Vector3, vel: Vector3) -> Array:
    var c := _cc(pos)
    var out: Array = []
    for dx in range(-load_r, load_r + 1):
        for dz in range(-load_r, load_r + 1):
            var w := c + Vector2i(dx, dz)
            if _valid(w) and not out.has(w):
                out.append(w)
    if vel.length() > 1.0:
        var dir := vel.normalized()
        for k in range(1, 4):
            var w := _cc(pos + dir * k * CHUNK * S * 0.9)
            if _valid(w) and not out.has(w):
                out.append(w)
    out.sort_custom(func(a, b): return (a - c).length_squared() < (b - c).length_squared())
    return out


func update_streaming(pos: Vector3, vel: Vector3) -> void:
    var c := _cc(pos)
    for w in _wanted(pos, vel):
        if not chunks.has(w) and not _queue.has(w):
            _queue.append(w)
    for k in chunks.keys():
        if absi(k.x - c.x) > load_r + 1 or absi(k.y - c.y) > load_r + 1:
            chunks[k].queue_free()
            chunks.erase(k)
    _queue = _queue.filter(func(q): return absi(q.x - c.x) <= load_r + 2 and absi(q.y - c.y) <= load_r + 2)


func _process(_d: float) -> void:
    if not _queue.is_empty():
        var k: Vector2i = _queue.pop_front()
        _ensure(k)


func _ensure(c: Vector2i) -> void:
    if chunks.has(c) or not _valid(c):
        return
    var node := Node3D.new()
    node.name = "C_%d_%d" % [c.x, c.y]
    for bi in range(c.x * CHUNK, (c.x + 1) * CHUNK):
        for bj in range(c.y * CHUNK, (c.y + 1) * CHUNK):
            _build_block(node, bi, bj)
    add_child(node)
    chunks[c] = node


func preload_around(pos: Vector3, cb: Callable) -> void:
    var need := _wanted(pos, Vector3.ZERO)
    var total := maxi(1, need.size())
    var k := 0
    for c in need:
        _ensure(c)
        k += 1
        cb.call(float(k) / total)
        await get_tree().process_frame


func set_quality(q: int) -> void:
    load_r = [1, 2, 3][clampi(q, 0, 2)]

func set_night(active: bool) -> void:
    for l in street_lights:
        if is_instance_valid(l):
            l.visible = active
            l.light_energy = 1.8 if active else 0.0


# ---------- בנייה ----------
func _m(c: Color) -> StandardMaterial3D:
    var k := c.to_html()
    if _mats.has(k):
        return _mats[k]
    var m := StandardMaterial3D.new()
    m.albedo_color = c
    m.roughness = 0.9
    _mats[k] = m
    return m


func _box(parent: Node, pos: Vector3, size: Vector3, col: Color, solid := true) -> MeshInstance3D:
    var mi := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = size
    mi.mesh = bm
    mi.material_override = _m(col)
    mi.position = pos
    parent.add_child(mi)
    if solid:
        _body(mi, size)
    return mi


func _body(parent: Node, size: Vector3) -> void:
    var sb := StaticBody3D.new()
    var cs := CollisionShape3D.new()
    var sh := BoxShape3D.new()
    sh.size = size
    cs.shape = sh
    sb.add_child(cs)
    parent.add_child(sb)


func _mesh_solid(parent: Node, mesh: Mesh, pos: Vector3, col: Color, bsize: Vector3) -> void:
    var mi := MeshInstance3D.new()
    mi.mesh = mesh
    mi.material_override = _m(col)
    mi.position = pos
    parent.add_child(mi)
    _body(mi, bsize)


func _label(parent: Node, text: String, pos: Vector3, px: int, col: Color) -> void:
    var l := Label3D.new()
    l.text = text
    l.font = Game.font
    l.font_size = px
    l.pixel_size = 0.01
    l.modulate = col
    l.outline_size = 6
    l.outline_modulate = Color(0, 0, 0, 0.55)
    l.position = pos
    parent.add_child(l)


func _street_light(parent: Node3D, pos: Vector3) -> void:
    _box(parent, pos + Vector3(0, 2.0, 0), Vector3(0.10, 4.0, 0.10), Color("30343b"), false)
    _box(parent, pos + Vector3(0, 4.0, -0.18), Vector3(0.7, 0.10, 0.10), Color("30343b"), false)
    var l := OmniLight3D.new()
    l.position = pos + Vector3(0, 3.85, -0.28)
    l.omni_range = 8.0
    l.light_color = Color("ffd58a")
    l.light_energy = 0.0
    l.shadow_enabled = false
    l.visible = false
    parent.add_child(l)
    street_lights.append(l)


func _tree(parent: Node, pos: Vector3) -> void:
    var t := CylinderMesh.new()
    t.top_radius = 0.15
    t.bottom_radius = 0.2
    t.height = 2.6
    var mi := MeshInstance3D.new()
    mi.mesh = t
    mi.material_override = _m(Color("5b4636"))
    mi.position = pos + Vector3(0, 1.3, 0)
    parent.add_child(mi)
    var s := SphereMesh.new()
    s.radius = 1.5
    s.height = 3.0
    var cm := MeshInstance3D.new()
    cm.mesh = s
    cm.material_override = _m(Color("3f7d3a"))
    cm.position = pos + Vector3(0, 3.4, 0)
    parent.add_child(cm)


func _wall(pos: Vector3, size: Vector3) -> void:
    var sb := StaticBody3D.new()
    sb.position = pos
    var cs := CollisionShape3D.new()
    var sh := BoxShape3D.new()
    sh.size = size
    cs.shape = sh
    sb.add_child(cs)
    add_child(sb)


func _build_ground() -> void:
    _box(self, Vector3(SIZE * 0.5 - 15.0, -0.5, SIZE * 0.5), Vector3(SIZE + 150.0, 1.0, SIZE + 120.0), Color("34373c"))
    _box(self, Vector3(-48.5, 0.02, SIZE * 0.5), Vector3(83.0, 0.04, SIZE + 120.0), Color("e3cf9f"), false)
    _box(self, Vector3(-345.0, -0.3, SIZE * 0.5), Vector3(510.0, 0.2, SIZE + 400.0), Color("2a7fb8"), false)
    _wall(Vector3(-90.0, 10, SIZE * 0.5), Vector3(2, 20, SIZE + 120))
    _wall(Vector3(SIZE + 60.0, 10, SIZE * 0.5), Vector3(2, 20, SIZE + 120))
    _wall(Vector3(SIZE * 0.5, 10, -60.0), Vector3(SIZE + 150, 20, 2))
    _wall(Vector3(SIZE * 0.5, 10, SIZE + 60.0), Vector3(SIZE + 150, 20, 2))


func _build_block(root: Node3D, bi: int, bj: int) -> void:
    var p := poi(bi, bj)
    var rng := RandomNumberGenerator.new()
    rng.seed = p.h
    var w := S - R
    var x0 := bi * S + R * 0.5
    var z0 := bj * S + R * 0.5
    var cx := x0 + w * 0.5
    var cz := z0 + w * 0.5
    var z_front := z0 + w - SET
    var door: Vector3 = p.door
    _box(root, Vector3(cx, 0.025, cz), Vector3(w, 0.05, w), Color("c9c6bf"), false)
    _box(root, Vector3(cx, 0.012, (bj + 1) * S), Vector3(w - 6.0, 0.02, 0.25), Color("e8e8e8"), false)
    _box(root, Vector3((bi + 1) * S, 0.012, cz), Vector3(0.25, 0.02, w - 6.0), Color("e8e8e8"), false)
    _tree(root, Vector3(x0 + 6.0, 0, z_front + 3.0))
    _tree(root, Vector3(x0 + w - 6.0, 0, z_front + 3.0))
    _street_light(root, Vector3(x0 + 3.0, 0, z_front + 4.0))
    _street_light(root, Vector3(x0 + w - 3.0, 0, z_front + 4.0))
    if p.kind == "landmark":
        _build_landmark(root, p, cx, cz, z_front, w)
        return
    var hgt := rng.randf_range(10.0, 34.0)
    var col: Color = PALETTE[rng.randi() % PALETTE.size()]
    # Neighbourhood variation: older low-rise, modern glass, and stepped rooflines.
    var style := rng.randi_range(0, 2)
    if p.kind == "restaurant":
        hgt = rng.randf_range(7.0, 10.0)
    elif p.kind == "bank":
        hgt = 14.0
        col = Color("d5dde6")
    if style == 0: hgt *= 0.72
    elif style == 2: hgt *= 1.22
    var bw := (w - 2.0 * SET) * rng.randf_range(0.62, 1.0)
    var bd := (w - 2.0 * SET) * rng.randf_range(0.6, 1.0)
    var bz := z_front - bd * 0.5
    _box(root, Vector3(cx, hgt * 0.5, bz), Vector3(bw, hgt, bd), col)
    if style == 2:
        _box(root, Vector3(cx, hgt + 1.0, bz), Vector3(bw * 0.72, 2.0, bd * 0.72), col.lightened(0.08))
    # Ground-floor storefront glazing gives commercial blocks a distinct street edge.
    if p.kind == "restaurant":
        _box(root, Vector3(cx, 1.8, z_front + 0.08), Vector3(bw * 0.7, 2.7, 0.08), Color("7aa4b5"), false)
    for f in range(floori(hgt / 3.4)):
        _box(root, Vector3(cx, 2.2 + f * 3.4, bz), Vector3(bw + 0.06, 1.1, bd + 0.06), Color("4a5a68"), false)
    _box(root, Vector3(door.x, 1.2, z_front + 0.06), Vector3(1.6, 2.4, 0.12), Color("2b2b2b"), false)
    if p.kind == "home":
        _label(root, p.addr, Vector3(door.x, 2.9, z_front + 0.2), 44, Color.WHITE)
    else:
        var sc: Color = SIGN_COLS[rng.randi() % SIGN_COLS.size()]
        if p.kind == "bank":
            sc = Color("1d4f91")
        _box(root, Vector3(door.x, 3.9, z_front + 0.08), Vector3(7.0, 1.4, 0.14), sc, false)
        _label(root, p.name, Vector3(door.x, 3.9, z_front + 0.2), 90, Color.WHITE)
        if p.kind == "bank":
            _box(root, Vector3(door.x + 3.0, 1.0, z_front + 0.4), Vector3(0.7, 1.4, 0.5), Color("37474f"), false)


func _build_landmark(root: Node3D, p: Dictionary, cx: float, cz: float, z_front: float, w: float) -> void:
    var door: Vector3 = p.door
    var sub: String = p.sub
    var sign_y := 6.0
    match sub:
        "azrieli":
            var cy := CylinderMesh.new()
            cy.top_radius = 6.0
            cy.bottom_radius = 6.0
            cy.height = 110.0
            cy.radial_segments = 24
            _mesh_solid(root, cy, Vector3(cx - 14.0, 55.0, cz), Color("9fb3c4"), Vector3(12, 110, 12))
            var tr := CylinderMesh.new()
            tr.top_radius = 7.0
            tr.bottom_radius = 7.0
            tr.height = 110.0
            tr.radial_segments = 3
            _mesh_solid(root, tr, Vector3(cx, 55.0, cz), Color("8da4b8"), Vector3(12, 110, 11))
            _box(root, Vector3(cx + 14.0, 55.0, cz), Vector3(11, 110, 11), Color("a9bccb"))
        "mall":
            _box(root, Vector3(cx, 8.0, cz), Vector3(38, 16, 30), Color("c9d1d6"))
            sign_y = 10.0
        "market":
            for a in range(3):
                for b in range(5):
                    _box(root, Vector3(cx - 16.0 + b * 8.0, 1.2, cz - 8.0 + a * 8.0), Vector3(4, 2.4, 3), Color(SIGN_COLS[(a + b) % SIGN_COLS.size()]))
        "beach":
            _box(root, Vector3(cx, 1.75, cz), Vector3(7, 3.5, 5), Color("f2efe6"))
            _box(root, Vector3(cx + 12.0, 2.0, cz), Vector3(2, 4, 2), Color("d62828"))
            _box(root, Vector3(cx + 12.0, 4.5, cz), Vector3(3, 1.6, 3), Color("f2c200"))
        "plaza":
            var fc := CylinderMesh.new()
            fc.top_radius = 3.0
            fc.bottom_radius = 3.0
            fc.height = 1.0
            _mesh_solid(root, fc, Vector3(cx, 0.5, cz), Color("9ec5d8"), Vector3(6, 1, 6))
            for k in range(4):
                _tree(root, Vector3(cx - 12.0 + k * 8.0, 0, cz - 10.0))
        "ayalon":
            _box(root, Vector3(cx - 12.0, 0.6, cz), Vector3(2, 1.2, w - 8.0), Color("8d8d8d"))
            _box(root, Vector3(cx + 12.0, 0.6, cz), Vector3(2, 1.2, w - 8.0), Color("8d8d8d"))
            sign_y = 4.0
    _label(root, p.name, Vector3(door.x, sign_y, z_front + 0.4), 110, Color("ffd600"))
