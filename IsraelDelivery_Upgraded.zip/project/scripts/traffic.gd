class_name TrafficCar
extends Node3D
## רכב תנועה קל משקל: נע רק לאורך כביש ישר, ללא collision וללא יצירה בכל פריים.

var axis := 0 # 0 = east/west, 1 = north/south
var direction := 1.0
var speed := 5.0
var wrap_min := 0.0
var wrap_max := 1536.0

func setup(a: int, d: float, s: float, pos: Vector3, col: Color) -> void:
    axis = a
    direction = d
    speed = s
    global_position = pos
    rotation.y = 0.0 if axis == 0 else PI / 2.0
    var body := MeshInstance3D.new()
    var mesh := BoxMesh.new()
    mesh.size = Vector3(2.2, 0.75, 4.0) if axis == 0 else Vector3(4.0, 0.75, 2.2)
    body.mesh = mesh
    var mat := StandardMaterial3D.new()
    mat.albedo_color = col
    mat.roughness = 0.65
    body.material_override = mat
    body.position.y = 0.45
    add_child(body)
    var roof := MeshInstance3D.new()
    var rm := BoxMesh.new()
    rm.size = Vector3(1.65, 0.35, 1.9) if axis == 0 else Vector3(1.9, 0.35, 1.65)
    roof.mesh = rm
    roof.material_override = mat
    roof.position.y = 0.95
    add_child(roof)

func _process(delta: float) -> void:
    if axis == 0:
        position.x += direction * speed * delta
        if position.x > wrap_max: position.x = wrap_min
        elif position.x < wrap_min: position.x = wrap_max
    else:
        position.z += direction * speed * delta
        if position.z > wrap_max: position.z = wrap_min
        elif position.z < wrap_min: position.z = wrap_max
