class_name Player
extends CharacterBody3D
## שליח + כלי תחבורה: פיזיקה, מצלמות (גוף ראשון/שלישי), אנימציית רכיבה ואיסוף.

var speed := 0.0
var heading := 0.0
var cam_yaw := 0.0
var cam_pitch := 0.0
var first_person := false
var input_enabled := true
var phase := 0.0
var kind := "ebike"
var fig: Figure
var veh: Node3D
var wheels: Array = []
var pedals: Array = []
var cam: Camera3D
var light: SpotLight3D
var bag: Node3D
var mouse_idle := 0.0
var _lean := 0.0
var _t := 0.0
var _snap_cam := true
var look_active := false


func _ready() -> void:
    var cs := CollisionShape3D.new()
    var bs := BoxShape3D.new()
    bs.size = Vector3(0.7, 1.0, 1.6)
    cs.shape = bs
    cs.position = Vector3(0, 0.55, 0)
    add_child(cs)
    cam = Camera3D.new()
    cam.top_level = true
    cam.far = 900.0
    add_child(cam)
    cam.current = true
    light = SpotLight3D.new()
    light.position = Vector3(0, 1.0, -0.7)
    light.rotation.x = -0.08
    light.spot_range = 40.0
    light.spot_angle = 35.0
    add_child(light)
    floor_snap_length = 0.3
    bag = Node3D.new()
    bag.visible = false
    add_child(bag)
    var bm := MeshInstance3D.new()
    var b := BoxMesh.new()
    b.size = Vector3(0.28, 0.3, 0.16)
    bm.mesh = b
    bm.material_override = _mat(Color("111111"))
    bag.add_child(bm)


static func _mat(c: Color) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = c
    m.roughness = 0.8
    return m


func setup(look: Dictionary, company: String, k: String) -> void:
    kind = k
    wheels.clear()
    pedals.clear()
    if veh:
        veh.queue_free()
    if fig:
        fig.queue_free()
    veh = _build_vehicle(k)
    add_child(veh)
    fig = Figure.new()
    add_child(fig)
    fig.build(look, company)
    fig.carry_mark.visible = false
    var st := Game.vehicle_stats()
    light.light_energy = 1.0 + 1.5 * float(st.light)
    _snap_cam = true


func _bx(parent: Node3D, size: Vector3, pos: Vector3, col: Color, rot := Vector3.ZERO) -> MeshInstance3D:
    var mi := MeshInstance3D.new()
    var b := BoxMesh.new()
    b.size = size
    mi.mesh = b
    mi.material_override = _mat(col)
    mi.position = pos
    mi.rotation = rot
    parent.add_child(mi)
    return mi


func _wheel(parent: Node3D, pos: Vector3, r: float, w: float) -> void:
    var piv := Node3D.new()
    piv.position = pos
    parent.add_child(piv)
    var cy := CylinderMesh.new()
    cy.top_radius = r
    cy.bottom_radius = r
    cy.height = w
    var mi := MeshInstance3D.new()
    mi.mesh = cy
    mi.rotation.z = PI / 2.0
    mi.material_override = _mat(Color("141414"))
    piv.add_child(mi)
    _bx(piv, Vector3(w + 0.02, 0.03, r * 1.9), Vector3.ZERO, Color("b0b0b0"))
    wheels.append({"n": piv, "r": r})


func _build_vehicle(k: String) -> Node3D:
    var v := Node3D.new()
    match k:
        "ebike":
            _wheel(v, Vector3(0, 0.34, 0.55), 0.34, 0.05)
            _wheel(v, Vector3(0, 0.34, -0.6), 0.34, 0.05)
            _bx(v, Vector3(0.05, 0.06, 0.62), Vector3(0, 0.32, 0.25), Color("e8e8e8"))
            _bx(v, Vector3(0.05, 0.6, 0.05), Vector3(0, 0.6, 0.05), Color("e8e8e8"))
            _bx(v, Vector3(0.1, 0.04, 0.26), Vector3(0, 0.9, 0.12), Color("111111"))
            _bx(v, Vector3(0.1, 0.12, 0.4), Vector3(0, 0.5, -0.2), Color("1a1a1a"))
            _bx(v, Vector3(0.04, 0.82, 0.04), Vector3(0, 0.715, -0.43), Color("e8e8e8"), Vector3(deg_to_rad(24), 0, 0))
            _bx(v, Vector3(0.46, 0.03, 0.03), Vector3(0, 1.09, -0.27), Color("111111"))
            _bx(v, Vector3(0.04, 0.35, 0.04), Vector3(0, 0.34, -0.6), Color("c8c8c8"))
            for s in [-1.0, 1.0]:
                pedals.append(_bx(v, Vector3(0.12, 0.03, 0.08), Vector3(s * 0.17, 0.3, -0.05), Color("111111")))
        "scooter":
            _wheel(v, Vector3(0, 0.12, 0.6), 0.12, 0.04)
            _wheel(v, Vector3(0, 0.12, -0.35), 0.12, 0.04)
            _bx(v, Vector3(0.2, 0.04, 0.65), Vector3(0, 0.15, 0.22), Color("2d2d2d"))
            _bx(v, Vector3(0.035, 1.15, 0.035), Vector3(0, 0.72, -0.315), Color("c8c8c8"), Vector3(deg_to_rad(3.5), 0, 0))
            _bx(v, Vector3(0.42, 0.03, 0.03), Vector3(0, 1.30, -0.28), Color("111111"))
            _bx(v, Vector3(0.14, 0.08, 0.4), Vector3(0, 0.1, 0.2), Color("1a1a1a"))
        "moped":
            _wheel(v, Vector3(0, 0.22, 0.6), 0.22, 0.1)
            _wheel(v, Vector3(0, 0.22, -0.62), 0.22, 0.1)
            _bx(v, Vector3(0.34, 0.28, 0.95), Vector3(0, 0.34, 0.15), Color("5f8f8a"))
            _bx(v, Vector3(0.36, 0.2, 0.3), Vector3(0, 0.36, 0.45), Color("a93226"))
            _bx(v, Vector3(0.36, 0.1, 0.3), Vector3(0, 0.38, 0.0), Color("7b5a3a"))
            _bx(v, Vector3(0.32, 0.04, 0.45), Vector3(0, 0.2, -0.2), Color("2a2a2a"))
            _bx(v, Vector3(0.32, 0.6, 0.08), Vector3(0, 0.65, -0.45), Color("5f8f8a"))
            _bx(v, Vector3(0.3, 0.12, 0.55), Vector3(0, 0.7, 0.3), Color("1a1a1a"))
            _bx(v, Vector3(0.04, 0.56, 0.04), Vector3(0, 0.8, -0.425), Color("9a9a9a"), Vector3(deg_to_rad(26.5), 0, 0))
            _bx(v, Vector3(0.5, 0.04, 0.04), Vector3(0, 1.05, -0.3), Color("111111"))
            _bx(v, Vector3(0.14, 0.14, 0.1), Vector3(0, 1.0, -0.4), Color("e0d9a0"))
            _bx(v, Vector3(0.06, 0.06, 0.5), Vector3(0.2, 0.2, 0.5), Color("8a8a8a"))
    return v


func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_RIGHT:
        look_active = event.pressed
        if event.pressed:
            Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
        return
    if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED and (look_active or Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT)):
        cam_yaw -= event.relative.x * 0.003
        cam_pitch = clampf(cam_pitch - event.relative.y * 0.003, -0.6, 0.6)
        cam_yaw = clampf(cam_yaw, -1.5, 1.5) if first_person else clampf(cam_yaw, -PI, PI)
        mouse_idle = 0.0
    elif event.is_action_pressed("cam"):
        first_person = not first_person
        _snap_cam = true


func _physics_process(delta: float) -> void:
    if fig == null:
        return
    _t += delta
    var st := Game.vehicle_stats()
    var inp := 0.0
    var steer := 0.0
    var braking := false
    if input_enabled:
        if Input.is_action_just_pressed("boost"):
            Game.use_boost()
        inp = Input.get_axis("back", "forward")
        steer = Input.get_axis("right", "left")
        braking = Input.is_action_pressed("brake")
    var boost_factor := 1.35 if Game.boost_active else 1.0
    if inp > 0.0:
        speed = move_toward(speed, st.max_ms * boost_factor, st.accel * delta * (1.15 if Game.boost_active else 1.0))
    elif inp < 0.0:
        if speed > 0.5:
            speed = move_toward(speed, 0.0, st.brake * delta)
        else:
            speed = move_toward(speed, -2.5, st.accel * delta)
    else:
        speed = move_toward(speed, 0.0, 1.2 * delta)
    if braking:
        speed = move_toward(speed, 0.0, st.brake * 1.3 * delta)
    var sf := clampf(absf(speed) / 4.0, 0.0, 1.0)
    heading += steer * st.turn * sf * delta * signf(speed if speed != 0.0 else 1.0)
    rotation.y = heading
    var fwd := -global_transform.basis.z
    velocity.x = fwd.x * speed
    velocity.z = fwd.z * speed
    if is_on_floor():
        velocity.y = 0.0
    else:
        velocity.y -= 20.0 * delta
    move_and_slide()
    speed = Vector3(velocity.x, 0, velocity.z).dot(fwd)
    if global_position.y < -5.0:
        global_position = Game.last_pos
        speed = 0.0
    Game.stats.dist = float(Game.stats.dist) + absf(speed) * delta
    light.visible = Game.is_night()
    mouse_idle += delta
    if mouse_idle > 1.5:
        cam_yaw = lerp_angle(cam_yaw, 0.0, 2.0 * delta)
        cam_pitch = lerpf(cam_pitch, 0.0, 2.0 * delta)
    _animate(delta, steer)
    _update_camera(delta, st)


func _animate(delta: float, steer: float) -> void:
    phase += speed * delta * 3.2
    fig.ride_pose(kind, phase if kind == "ebike" else 0.0)
    for i in range(pedals.size()):
        var s := -1.0 if i == 0 else 1.0
        var ph := phase + (0.0 if i == 0 else PI)
        pedals[i].position = Vector3(s * 0.17, 0.3 + 0.12 * cos(ph), -0.05 + 0.12 * sin(ph))
    for w in wheels:
        w.n.rotation.x -= speed / w.r * delta
    _lean = lerpf(_lean, steer * clampf(absf(speed) / 8.0, 0.0, 1.0) * 0.2, 6.0 * delta)
    veh.rotation.z = _lean
    fig.rotation.z = _lean
    var vib := 0.0
    if kind == "moped":
        vib = sin(_t * 60.0) * 0.004 * clampf(absf(speed) / 3.0, 0.0, 1.0)
    veh.position.y = vib
    fig.position.y = vib
    fig.head.rotation.y = clampf(cam_yaw * 0.4, -0.6, 0.6) if not first_person else 0.0
    fig.helmet_node.visible = not first_person
    fig.hair_node.visible = not first_person
    fig.head.visible = not first_person
    for c in fig.torso.get_children():
        if c is MeshInstance3D or c is Label3D:
            c.visible = not first_person


func _update_camera(delta: float, st: Dictionary) -> void:
    cam.fov = float(Game.settings.get("fov", 75.0))
    var yaw := heading + cam_yaw
    var bas := Basis(Vector3.UP, yaw)
    var shake := (10.0 - float(st.comfort)) * 0.0025 * clampf(absf(speed) / 7.0, 0.0, 1.0)
    if first_person:
        var eye := to_global(Vector3(0, fig.pelvis.position.y + 0.82, fig.pelvis.position.z - 0.12))
        cam.global_position = eye + Vector3(0, sin(_t * 17.0) * shake, 0)
        cam.global_transform.basis = bas * Basis(Vector3.RIGHT, cam_pitch)
    else:
        var pivot := global_position + Vector3(0, 1.5, 0)
        var desired := pivot + bas * Vector3(0, 0.9 - cam_pitch * 3.0, 4.6)
        var q := PhysicsRayQueryParameters3D.create(pivot, desired, 1, [get_rid()])
        var hit := get_world_3d().direct_space_state.intersect_ray(q)
        if not hit.is_empty():
            desired = hit.position + hit.normal * 0.25
        if _snap_cam:
            cam.global_position = desired
        else:
            cam.global_position = cam.global_position.lerp(desired, 1.0 - exp(-10.0 * delta))
        cam.look_at(pivot + bas * Vector3(0, 0, -3), Vector3.UP)
    _snap_cam = false


func play_pickup() -> void:
    bag.visible = true
    bag.position = Vector3(0.25, 1.0, -0.55)
    var target := to_local(fig.torso.to_global(Vector3(0, 0.62, 0.24)))
    var tw := create_tween()
    tw.tween_property(bag, "position", Vector3(0.25, 0.9, -0.25), 0.35)
    tw.tween_property(bag, "position", target, 0.35)
    tw.tween_callback(func():
        bag.visible = false
        fig.carry_mark.visible = true)


func drop_bag() -> void:
    fig.carry_mark.visible = false


func set_carrying(c: bool) -> void:
    if fig and fig.carry_mark:
        fig.carry_mark.visible = c
